/*
*  Power BI Visual CLI
*
*  Copyright (c) Microsoft Corporation
*  All rights reserved.
*  MIT License
*
*  Permission is hereby granted, free of charge, to any person obtaining a copy
*  of this software and associated documentation files (the ""Software""), to deal
*  in the Software without restriction, including without limitation the rights
*  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
*  copies of the Software, and to permit persons to whom the Software is
*  furnished to do so, subject to the following conditions:
*
*  The above copyright notice and this permission notice shall be included in
*  all copies or substantial portions of the Software.
*
*  THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
*  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
*  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
*  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
*  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
*  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
*  THE SOFTWARE.
*/
"use strict";
// import "@babel/polyfill";
import "./../style/visual.less";
import powerbi from "powerbi-visuals-api";
import VisualConstructorOptions = powerbi.extensibility.visual.VisualConstructorOptions;
import VisualUpdateOptions = powerbi.extensibility.visual.VisualUpdateOptions;
import IVisual = powerbi.extensibility.visual.IVisual;
import EnumerateVisualObjectInstancesOptions = powerbi.EnumerateVisualObjectInstancesOptions;
import VisualObjectInstance = powerbi.VisualObjectInstance;
import DataView = powerbi.DataView;
import VisualObjectInstanceEnumerationObject = powerbi.VisualObjectInstanceEnumerationObject;

import { VisualSettings } from "./settings";

export class mdTable {

    columns: mdColumn[];

    constructor() {
        this.columns = [];
    }

    TotalColumnas(): number {
        return this.columns.length;
    }

    TotalFilas(): number {
        return this.columns[0].values.length;
    }

    load(data: DataView) {
        this.columns = []
        let cats = data.categorical.categories.length;
        for (let i = 0; i < cats; i++) {
            let col: mdColumn = new mdColumn();
            col.header = data.categorical.categories[i].source.displayName
            let valuesLength = data.categorical.categories[i].values.length
            for (let j = 0; j < valuesLength; j++) {
                col.values.push(data.categorical.categories[i].values[j].toString())
            }
            this.columns.push(col);
        }

        let vals = data.categorical.values.length;
        for (let i = 0; i < vals; i++) {
            let col: mdColumn = new mdColumn();
            col.header = data.categorical.values[i].source.displayName
            let valuesLength = data.categorical.values[i].values.length
            for (let j = 0; j < valuesLength; j++) {
                col.values.push(data.categorical.values[i].values[j].toString())
            }
            this.columns.push(col);
        }
    }
}
export class mdColumn {
    values: string[];
    name: string;
    header: string;
    type: string;
    constructor() {
        this.values = [];
    }
}

export class Visual implements IVisual {
    private target: HTMLElement;
    private tabla: HTMLElement;
    private updateCount: number;
    private settings: VisualSettings;
    private textNode: Text;
    private mdtabla: mdTable;

    constructor(options: VisualConstructorOptions) {
        console.log('Visual constructor', options);
        this.target = options.element;
        this.updateCount = 0;
        if (typeof document !== "undefined") {


            // ------------------- Update Count display: -------------------
            // const new_p: HTMLElement = document.createElement("p");
            // new_p.appendChild(document.createTextNode("Update count:"));
            // const new_em: HTMLElement = document.createElement("em");
            // this.textNode = document.createTextNode(this.updateCount.toString());
            // new_em.appendChild(this.textNode);
            // new_p.appendChild(new_em);
            //this.target.appendChild(new_p);


            // ------------------- Actual content: -------------------
            this.tabla = document.createElement("table");
            let fila: HTMLElement = document.createElement("tr");
            let celda: HTMLElement = document.createElement("td");
            celda.textContent = "hola"
            fila.appendChild(celda)
            this.tabla.appendChild(fila)
            this.tabla.setAttribute('style', 'border: none');
            this.target.appendChild(this.tabla)
            this.mdtabla = new mdTable();
        }
    }

    public update(options: VisualUpdateOptions) {
        //let dataView: DataView = options.dataViews[0];

        debugger;
        this.mdtabla.load(options.dataViews[0])


        var child = this.tabla.lastElementChild;
        while (child) {
            this.tabla.removeChild(child);
            child = this.tabla.lastElementChild;
        }

        // ------------------- Creacion de cabecera -------------------
        let cabecera: HTMLElement = document.createElement("tr");
        let columnaLEstadoIndex;
        for (let columnaIndex = 0; columnaIndex < this.mdtabla.TotalColumnas(); columnaIndex++) {
            let celda: HTMLElement = document.createElement("td");
            celda.textContent = this.mdtabla.columns[columnaIndex].header;
            celda.setAttribute('bgcolor', '#f0f0f0');
            celda.setAttribute('style', 'text-align:center; padding: 0 70px; font-size: 9pt;')

            if (celda.textContent == "L. Descripcion") {
                celda.setAttribute('style', 'text-align:center; padding: 0 140px; font-size: 9pt;')
            }

            cabecera.appendChild(celda);

            if (celda.textContent == "L. Estado") {
                columnaLEstadoIndex = columnaIndex;
            }
        }
        this.tabla.appendChild(cabecera);

        // ------------------- Formacion de cuerpo -------------------
        for (let filaIndex = 0; filaIndex < this.mdtabla.TotalFilas(); filaIndex++) {
            let fila: HTMLElement = document.createElement("tr");
            for (let columnaIndex = 0; columnaIndex < this.mdtabla.TotalColumnas(); columnaIndex++) {
                let celda: HTMLElement = document.createElement("td");
                celda.textContent = this.mdtabla.columns[columnaIndex].values[filaIndex];
                celda.setAttribute('style', ''); //Initialize style

                if (this.mdtabla.columns[columnaIndex].header == "L. Estado") {
                    switch (this.mdtabla.columns[columnaIndex].values[filaIndex]) {
                        case "Disponible": {
                            celda.setAttribute("bgcolor", "#009c00")
                            break
                        }
                        case "Hablando": {
                            celda.setAttribute("bgcolor", "#c00000")
                            break
                        }
                        case "Parado": {
                            celda.setAttribute("bgcolor", "#474747")
                            break
                        }
                        case "Trabajo tras llamada": {
                            celda.setAttribute("bgcolor", "#0070c0")
                            break
                        }
                        default: {
                            celda.setAttribute("bgcolor", "#c0070c0")
                        }
                    }
                    celda.setAttribute("style", "color:white; font-weight: bold;")
                } 

                if (this.mdtabla.columns[columnaIndex].header == "L. T") {

                    let LEstado = this.mdtabla.columns[columnaLEstadoIndex].values[filaIndex];
                    let tiempo = this.mdtabla.columns[columnaIndex].values[filaIndex].split(':');

                    if ((LEstado == 'Hablando' || LEstado == 'Parado') && parseInt(tiempo[0]) >= 10) {
                        celda.setAttribute('style', 'color: red;')
                    }

                    if (LEstado == 'Trabajo tras llamada' && (parseInt(tiempo[0]) * 60 + parseInt(tiempo[1]) >= 90)) {
                        celda.setAttribute('style', 'color: red;')
                    }

                }

                // if (this.mdtabla.columns[columnaIndex].header == "Primera fecha: DateTime") {
                //     celda.textContent = celda.textContent.replace('.000Z', '');
                //     celda.textContent = celda.textContent.replace('T', ' - ');

                //     // celda.setAttribute("style", "color:white")
                // }

                celda.setAttribute('style', celda.getAttribute("style") + 'text-align:center; font-family: Arial; border: none; border-bottom: 1px solid #ddd; font-size: 9pt;')

                fila.appendChild(celda);
            }
            this.tabla.appendChild(fila)
        }

        // Set settings
        this.settings = Visual.parseSettings(options && options.dataViews && options.dataViews[0]);
        // console.log('Visual update', options);
        // debugger;
        // if (typeof this.tabla!== "undefined") {
        //     this.tabla.children[0].children[0].textContent = "caracola " + (this.updateCount++).toString()
        // }
        // if (typeof this.textNode !== "undefined") {
        //     this.textNode.textContent = (this.updateCount++).toString();

        // }

    }

    private static parseSettings(dataView: DataView): VisualSettings {
        return VisualSettings.parse(dataView) as VisualSettings;
    }

    /**
     * This function gets called for each of the objects defined in the capabilities files and allows you to select which of the
     * objects and properties you want to expose to the users in the property pane.
     *
     */
    public enumerateObjectInstances(options: EnumerateVisualObjectInstancesOptions): VisualObjectInstance[] | VisualObjectInstanceEnumerationObject {
        return VisualSettings.enumerateObjectInstances(this.settings || VisualSettings.getDefault(), options);
    }
}